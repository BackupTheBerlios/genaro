#addtext del cvs en linux/Fedora
#Ej de uso: bash addtextj codigo.txt
cvs -z3 add $1
cvs commit $1
