#addbin del cvs en linux/Fedora
#Ej de uso: bash addbinj musica.mid
cvs -z3 add -kb $1
cvs commit $1
