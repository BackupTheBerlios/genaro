#inicia sesion de cvs
#Ej de uso: bash entorno.sh bc24us
export CVS_RSH=ssh
export CVSROOT="$1@cvs.genaro.berlios.de:/cvsroot/genaro"
