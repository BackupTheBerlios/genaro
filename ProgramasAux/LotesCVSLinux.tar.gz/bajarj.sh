#bajar del cvs en linux/Fedora
#Ej de uso: bash bajarj Codigo
cvs -z3 co $1
