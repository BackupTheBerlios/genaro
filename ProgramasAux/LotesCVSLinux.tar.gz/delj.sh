#del del cvs en linux/Fedora
#Ej de uso: bash delj codigo.txt
cvs -z3 remove $1
cvs commit $1
